from django.apps import AppConfig


class SsAdminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ss_admin'
